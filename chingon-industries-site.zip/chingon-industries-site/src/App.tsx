import { type FormEvent, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowDownRight,
  ArrowUpRight,
  Boxes,
  Bot,
  Check,
  Cloud,
  Code2,
  Menu,
  Network,
  ShieldCheck,
  X,
  Zap,
} from 'lucide-react';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

const services = [
  {
    number: '01',
    title: 'SaaS Platform\nDevelopment',
    description: 'Products that turn a hard operational problem into a durable advantage. Designed for adoption, built for the long haul.',
    detail: 'Product architecture · Full-stack delivery',
    icon: Boxes,
  },
  {
    number: '02',
    title: 'Cloud\nInfrastructure',
    description: 'The reliable layer beneath your business. We shape cloud systems for speed, resilience, observability, and sensible cost.',
    detail: 'Cloud architecture · Platform engineering',
    icon: Cloud,
  },
  {
    number: '03',
    title: 'Security &\nCompliance',
    description: 'Trust is engineered in, not added on. Build a security posture your customers, auditors, and team can actually rely on.',
    detail: 'Risk programs · Identity · Controls',
    icon: ShieldCheck,
  },
  {
    number: '04',
    title: 'AI &\nAutomation',
    description: 'Useful intelligence with a clear job to do. We connect models, data, and workflows without losing human oversight.',
    detail: 'Applied AI · Workflow automation',
    icon: Bot,
  },
];

const principles = [
  ['01', 'Clarity before code', 'Every engagement starts with the decision your system needs to make, not the tool we want to use.'],
  ['02', 'Boring is a feature', 'The best infrastructure is dependable, observable, and easy for your team to own after we leave.'],
  ['03', 'Proof over theatre', 'We measure the work in outcomes: fewer incidents, faster releases, safer operations, better products.'],
];

function Header({ onContact }: { onContact: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const navItems = [
    ['Capabilities', '#capabilities'],
    ['Approach', '#approach'],
    ['Proof', '#proof'],
    ['About', '#about'],
  ];

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="fixed left-0 right-0 top-0 z-40 border-b border-[rgba(244,237,225,.12)] bg-[#10100f]/90 backdrop-blur-md">
      <div className="mx-auto flex h-[72px] max-w-[1240px] items-center justify-between px-5 lg:px-10">
        <a href="#top" onClick={closeMenu} className="flex items-center gap-3" data-testid="link-logo">
          <span className="flex h-8 w-8 items-center justify-center bg-[#ff5a16] text-[18px] font-bold text-[#17120e]">C</span>
          <span className="font-display text-[22px] font-bold uppercase tracking-[.08em] text-[#f1eadf]">Chingon<span className="text-[#ff5a16]">.</span></span>
        </a>
        <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
          {navItems.map(([label, href]) => (
            <a key={href} href={href} className="font-mono-custom text-[10px] uppercase tracking-[.14em] text-[#a49d92] transition-colors hover:text-[#ff7a45]" data-testid={`link-nav-${label.toLowerCase()}`}>
              {label}
            </a>
          ))}
        </nav>
        <button onClick={onContact} className="hidden items-center gap-3 border border-[#ff5a16] px-4 py-2.5 font-mono-custom text-[10px] uppercase tracking-[.13em] text-[#ff7a45] transition-colors hover:bg-[#ff5a16] hover:text-[#17120e] md:flex" data-testid="button-header-contact">
          Start a conversation <ArrowUpRight size={13} />
        </button>
        <button onClick={() => setMenuOpen(!menuOpen)} className="border border-[#49423b] p-2 text-[#e9dfd2] md:hidden" aria-label="Toggle navigation" data-testid="button-mobile-menu">
          {menuOpen ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>
      {menuOpen && (
        <nav className="border-t border-[#302d28] bg-[#171614] px-5 py-5 md:hidden" aria-label="Mobile navigation">
          {navItems.map(([label, href]) => (
            <a key={href} href={href} onClick={closeMenu} className="block border-b border-[#302d28] py-4 font-mono-custom text-[11px] uppercase tracking-[.14em] text-[#c9c0b4]" data-testid={`link-mobile-${label.toLowerCase()}`}>
              {label}
            </a>
          ))}
          <button onClick={() => { closeMenu(); onContact(); }} className="mt-5 flex w-full items-center justify-between bg-[#ff5a16] px-4 py-3 font-mono-custom text-[10px] uppercase tracking-[.13em] text-[#17120e]" data-testid="button-mobile-contact">
            Start a conversation <ArrowUpRight size={14} />
          </button>
        </nav>
      )}
    </header>
  );
}

function ContactModal({ onClose }: { onClose: () => void }) {
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (name.trim() && email.trim() && message.trim()) setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#090908]/80 p-0 backdrop-blur-sm sm:items-center sm:p-5" role="dialog" aria-modal="true" aria-labelledby="contact-title">
      <div className="relative w-full max-w-[680px] border border-[#4b4239] bg-[#191816] p-6 shadow-2xl sm:p-10">
        <button onClick={onClose} aria-label="Close contact form" className="absolute right-5 top-5 text-[#948c80] transition-colors hover:text-[#ff5a16]" data-testid="button-close-contact">
          <X size={20} />
        </button>
        {!submitted ? (
          <>
            <p className="eyebrow mb-5">Transmission open / 001</p>
            <h2 id="contact-title" className="font-display text-5xl uppercase leading-[.9] text-[#f1eadf] sm:text-7xl">Let&apos;s forge<br /><span className="text-[#ff5a16]">what&apos;s next.</span></h2>
            <p className="mt-5 max-w-[470px] text-sm leading-6 text-[#aaa196]">Tell us where the system is under strain. A real person from our team will follow up within two business days.</p>
            <form onSubmit={handleSubmit} className="mt-8 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="font-mono-custom text-[10px] uppercase tracking-[.1em] text-[#9f968a]">Your name
                  <input required value={name} onChange={(e) => setName(e.target.value)} className="contact-field mt-2 w-full border border-[#4b4239] bg-[#100f0e] px-3 py-3 font-sans text-sm text-[#f1eadf] transition-shadow" placeholder="First and last" data-testid="input-contact-name" />
                </label>
                <label className="font-mono-custom text-[10px] uppercase tracking-[.1em] text-[#9f968a]">Work email
                  <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="contact-field mt-2 w-full border border-[#4b4239] bg-[#100f0e] px-3 py-3 font-sans text-sm text-[#f1eadf] transition-shadow" placeholder="you@company.com" data-testid="input-contact-email" />
                </label>
              </div>
              <label className="block font-mono-custom text-[10px] uppercase tracking-[.1em] text-[#9f968a]">What are you building?
                <textarea required value={message} onChange={(e) => setMessage(e.target.value)} rows={4} className="contact-field mt-2 w-full resize-none border border-[#4b4239] bg-[#100f0e] px-3 py-3 font-sans text-sm text-[#f1eadf] transition-shadow" placeholder="A few words on the challenge, the timeline, or the ambition." data-testid="input-contact-message" />
              </label>
              <div className="flex flex-col gap-4 pt-2 sm:flex-row sm:items-center sm:justify-between">
                <p className="font-mono-custom text-[10px] text-[#776f66]">No pitch deck required.</p>
                <button type="submit" className="solid-button flex items-center justify-center gap-3 bg-[#ff5a16] px-5 py-3 font-mono-custom text-[10px] uppercase tracking-[.12em] text-[#17120e]" data-testid="button-submit-contact">
                  Send the signal <ArrowUpRight size={14} />
                </button>
              </div>
            </form>
          </>
        ) : (
          <div className="py-12 text-center sm:py-16">
            <div className="mx-auto flex h-14 w-14 items-center justify-center border border-[#ff5a16] text-[#ff5a16]"><Check size={25} /></div>
            <p className="eyebrow mt-7">Signal received</p>
            <h2 className="mt-4 font-display text-6xl uppercase leading-[.88] text-[#f1eadf]">We&apos;ll be<br /><span className="text-[#ff5a16]">in touch.</span></h2>
            <p className="mx-auto mt-5 max-w-[380px] text-sm leading-6 text-[#aaa196]">Your note is ready for the forge. If it is urgent, write to <a className="text-[#ff7a45] underline underline-offset-4" href="mailto:hello@chingon.industries" data-testid="link-contact-email">hello@chingon.industries</a>.</p>
            <button onClick={onClose} className="outline-button mt-8 border border-[#5a5148] px-5 py-3 font-mono-custom text-[10px] uppercase tracking-[.12em] text-[#e9dfd2]" data-testid="button-finish-contact">Back to site</button>
          </div>
        )}
      </div>
    </div>
  );
}

function Home() {
  const [contactOpen, setContactOpen] = useState(false);

  const openContact = () => setContactOpen(true);
  const scrollToContact = () => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });

  return (
    <div id="top" className="noise min-h-[100dvh] overflow-hidden bg-[#10100f] text-[#f1eadf]">
      <Header onContact={openContact} />

      <main>
        <section className="hero-visual site-grid relative flex min-h-[760px] items-end px-5 pb-20 pt-32 lg:min-h-[850px] lg:px-10 lg:pb-24" aria-labelledby="hero-heading">
          <div className="pointer-events-none absolute inset-0 opacity-40">
            <div className="server-rack absolute right-[4%] top-[12%] h-[56%] w-[24%] border border-[#66594f]/30 lg:right-[11%] lg:w-[20%]" />
            <div className="server-rack absolute right-[28%] top-[20%] hidden h-[42%] w-[12%] border border-[#66594f]/20 lg:block" />
            <div className="absolute bottom-[16%] left-[10%] h-px w-[55%] bg-[#ff5a16]/45" />
          </div>
          <div className="relative z-10 mx-auto w-full max-w-[1240px]">
            <div className="animate-rise mb-8 flex items-center gap-3">
              <span className="h-2 w-2 animate-[flicker_2s_infinite] bg-[#ff5a16]" />
              <span className="font-mono-custom text-[10px] uppercase tracking-[.18em] text-[#ff7a45]">System online / Chingon Industries</span>
            </div>
            <h1 id="hero-heading" className="display-xl animate-rise max-w-[1000px] text-[#f1eadf]">
              Engineered<br />for the <span className="text-[#ff5a16]">modern</span><br /><span className="text-[#ff5a16]">digital forge.</span>
            </h1>
            <div className="mt-12 flex flex-col gap-8 lg:ml-[42%] lg:flex-row lg:items-end lg:justify-between">
              <p className="animate-rise delay-1 max-w-[430px] text-[15px] leading-7 text-[#b1a99d]">We build the platforms, infrastructure, and intelligence that ambitious organizations depend on when the work gets real.</p>
              <a href="#capabilities" className="animate-rise delay-2 flex w-fit items-center gap-3 border-b border-[#ff5a16] pb-2 font-mono-custom text-[10px] uppercase tracking-[.13em] text-[#f1eadf] transition-colors hover:text-[#ff7a45]" data-testid="link-hero-capabilities">
                Inspect capabilities <ArrowDownRight size={15} className="text-[#ff5a16]" />
              </a>
            </div>
          </div>
          <div className="absolute bottom-6 left-5 right-5 flex justify-between font-mono-custom text-[9px] uppercase tracking-[.13em] text-[#70695f] lg:left-10 lg:right-10">
            <span>01 / 07</span><span>Digital infrastructure, made durable</span><span className="hidden sm:block">Est. 2016 — North America</span>
          </div>
        </section>

        <section className="border-y border-[#332e29] bg-[#171614] px-5 py-5 lg:px-10" aria-label="Capabilities statement">
          <div className="marquee-track mx-auto flex min-w-max items-center gap-8 font-display text-2xl uppercase tracking-[.04em] text-[#81786d] lg:justify-center">
            <span>Platforms</span><span className="text-[#ff5a16]">+</span><span>Infrastructure</span><span className="text-[#ff5a16]">+</span><span>Security</span><span className="text-[#ff5a16]">+</span><span>Intelligence</span><span className="text-[#ff5a16]">+</span><span>Platforms</span><span className="text-[#ff5a16]">+</span><span>Infrastructure</span>
          </div>
        </section>

        <section id="about" className="section-pad bg-[#f1eadf] text-[#191714]">
          <div className="mx-auto grid max-w-[1160px] gap-16 lg:grid-cols-[.82fr_1.18fr] lg:gap-24">
            <div>
              <p className="eyebrow !text-[#d94a12]">The brief / 02</p>
              <h2 className="display-lg mt-6 max-w-[460px]">Hard problems deserve <span className="text-[#db4d14]">serious</span> systems.</h2>
            </div>
            <div className="lg:pt-16">
              <p className="max-w-[580px] text-[21px] leading-[1.35] tracking-[-.02em] text-[#413b34]">Chingon is a technology partner for organizations whose digital systems are too important to leave to chance.</p>
              <p className="mt-7 max-w-[540px] text-[15px] leading-7 text-[#6d655c]">From first architecture decision to the millionth request, we bring product thinking and infrastructure discipline into the same room. No black boxes. No handoffs into the void. Just a senior team that stays accountable for the whole machine.</p>
              <a href="#approach" className="mt-10 inline-flex items-center gap-3 border-b border-[#d94a12] pb-2 font-mono-custom text-[10px] uppercase tracking-[.13em] text-[#d94a12]" data-testid="link-about-approach">How we work <ArrowUpRight size={14} /></a>
            </div>
          </div>
        </section>

        <section id="capabilities" className="section-pad site-grid bg-[#10100f]" aria-labelledby="capabilities-title">
          <div className="mx-auto max-w-[1160px]">
            <div className="mb-14 flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div><p className="eyebrow">The stack / 03</p><h2 id="capabilities-title" className="display-lg mt-5 max-w-[580px]">The right force<br /><span className="text-[#ff5a16]">for the job.</span></h2></div>
              <p className="max-w-[270px] text-sm leading-6 text-[#91887d]">One partner across the layers that make a modern business work. Connected by design, accountable in practice.</p>
            </div>
            <div className="grid border-l border-t border-[#37312c] md:grid-cols-2">
              {services.map((service) => {
                const Icon = service.icon;
                return (
                  <article key={service.number} className="service-card group relative min-h-[320px] border-b border-r border-[#37312c] p-7 lg:p-10" data-testid={`card-service-${service.number}`}>
                    <div className="flex items-start justify-between"><span className="font-mono-custom text-[11px] text-[#ff5a16]">{service.number}</span><Icon size={25} strokeWidth={1.3} className="text-[#887f73] transition-colors group-hover:text-[#ff5a16]" /></div>
                    <h3 className="mt-14 whitespace-pre-line font-display text-[46px] uppercase leading-[.84] tracking-[-.025em] text-[#f1eadf]">{service.title}</h3>
                    <p className="mt-6 max-w-[370px] text-sm leading-6 text-[#938b80]">{service.description}</p>
                    <div className="mt-7 flex items-center justify-between border-t border-[#36312b] pt-4"><span className="font-mono-custom text-[9px] uppercase tracking-[.09em] text-[#6e675e]">{service.detail}</span><ArrowUpRight size={16} className="service-arrow text-[#71695f]" /></div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section id="approach" className="section-pad bg-[#e7dfd3] text-[#191714]" aria-labelledby="approach-title">
          <div className="mx-auto max-w-[1160px]">
            <div className="grid gap-14 lg:grid-cols-[.8fr_1.2fr]">
              <div><p className="eyebrow !text-[#d94a12]">The method / 04</p><h2 id="approach-title" className="display-lg mt-5">Make it<br /><span className="text-[#d94a12]">make sense.</span></h2><p className="mt-8 max-w-[300px] text-sm leading-6 text-[#736a60]">We do the thinking in public. You get a clear path, visible progress, and a system your team can keep improving.</p></div>
              <div className="border-t border-[#b8ad9f]">
                {[
                  ['01', 'Frame the pressure', 'We map the constraint, the users, and the cost of staying where you are.'],
                  ['02', 'Forge the foundation', 'We design the architecture and prove the riskiest assumptions early.'],
                  ['03', 'Ship with signal', 'Small releases, honest observability, and a feedback loop built into the work.'],
                  ['04', 'Leave it stronger', 'Your team gets the context, controls, and confidence to run the system forward.'],
                ].map(([number, title, copy]) => (
                  <div key={number} className="grid grid-cols-[52px_1fr] gap-4 border-b border-[#b8ad9f] py-7 sm:grid-cols-[80px_1fr_1fr] sm:gap-7">
                    <span className="font-mono-custom text-[11px] text-[#d94a12]">{number}</span><h3 className="font-display text-3xl uppercase leading-none sm:text-4xl">{title}</h3><p className="col-start-2 text-sm leading-6 text-[#736a60] sm:col-start-3">{copy}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="proof" className="section-pad bg-[#171614]" aria-labelledby="proof-title">
          <div className="mx-auto max-w-[1160px]">
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end"><div><p className="eyebrow">The receipts / 05</p><h2 id="proof-title" className="display-lg mt-5">Built for the<br /><span className="text-[#ff5a16]">real world.</span></h2></div><p className="max-w-[290px] text-sm leading-6 text-[#91887d]">The measure of good engineering is what gets quieter, faster, and more possible on the other side.</p></div>
            <div className="mt-16 grid gap-5 lg:grid-cols-[1.5fr_1fr]">
              <article className="relative overflow-hidden border border-[#494039] bg-[#201d19] p-7 sm:p-10">
                <div className="absolute right-0 top-0 h-32 w-32 border-l border-b border-[#ff5a16]/30" />
                <div className="flex items-center justify-between"><span className="font-mono-custom text-[10px] uppercase tracking-[.14em] text-[#ff5a16]">Field note / 001</span><Network size={19} className="text-[#ff5a16]" /></div>
                <h3 className="mt-16 max-w-[570px] font-display text-5xl uppercase leading-[.86] text-[#f1eadf] sm:text-7xl">A clearer path from <span className="text-[#ff5a16]">complexity</span> to confidence.</h3>
                <p className="mt-8 max-w-[470px] text-sm leading-6 text-[#aaa196]">For a regulated operations team, we replaced brittle handoffs with a secure platform, automated the evidence trail, and gave every release a visible line back to business impact.</p>
                <div className="mt-12 grid max-w-[540px] grid-cols-2 gap-7 border-t border-[#494039] pt-6 sm:grid-cols-3">
                  <div><strong className="font-display text-4xl text-[#f1eadf]">3.4×</strong><p className="mt-1 font-mono-custom text-[9px] uppercase leading-4 tracking-[.08em] text-[#81776b]">faster release cadence</p></div>
                  <div><strong className="font-display text-4xl text-[#f1eadf]">−62%</strong><p className="mt-1 font-mono-custom text-[9px] uppercase leading-4 tracking-[.08em] text-[#81776b]">manual evidence work</p></div>
                  <div className="col-span-2 sm:col-span-1"><strong className="font-display text-4xl text-[#f1eadf]">0</strong><p className="mt-1 font-mono-custom text-[9px] uppercase leading-4 tracking-[.08em] text-[#81776b]">critical surprises</p></div>
                </div>
              </article>
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
                <div className="border border-[#494039] p-7"><Zap size={21} className="text-[#ff5a16]" /><p className="mt-12 font-display text-4xl uppercase leading-[.9] text-[#f1eadf]">Senior people.<br />Fewer layers.</p><p className="mt-5 text-sm leading-6 text-[#938b80]">The person shaping the system is in the room when decisions get made.</p></div>
                <div className="border border-[#494039] p-7"><Code2 size={21} className="text-[#ff5a16]" /><p className="mt-12 font-display text-4xl uppercase leading-[.9] text-[#f1eadf]">Architecture<br />that earns trust.</p><p className="mt-5 text-sm leading-6 text-[#938b80]">Readable systems, measurable controls, and no magic you cannot maintain.</p></div>
              </div>
            </div>
          </div>
        </section>

        <section className="section-pad bg-[#ff5a16] text-[#17120e]" aria-labelledby="principles-title">
          <div className="mx-auto max-w-[1160px]">
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end"><div><p className="eyebrow !text-[#633019]">The standard / 06</p><h2 id="principles-title" className="display-lg mt-5">No shortcuts<br />past <span className="text-[#f4ddc9]">trust.</span></h2></div><ShieldCheck size={52} strokeWidth={1} className="text-[#633019]" /></div>
            <div className="mt-16 grid border-l border-[#bc3e0d] md:grid-cols-3">
              {principles.map(([number, title, copy]) => <div key={number} className="border-b border-r border-t border-[#bc3e0d] p-7 lg:p-9"><span className="font-mono-custom text-[11px] text-[#633019]">{number}</span><h3 className="mt-16 font-display text-4xl uppercase leading-[.88]">{title}</h3><p className="mt-5 text-sm leading-6 text-[#6f321e]">{copy}</p></div>)}
            </div>
          </div>
        </section>

        <section id="contact" className="section-pad site-grid relative overflow-hidden bg-[#10100f]" aria-labelledby="contact-heading">
          <div className="mx-auto max-w-[1160px]">
            <div className="relative border border-[#403830] bg-[#151412] px-6 py-16 sm:px-12 lg:px-20 lg:py-24">
              <div className="absolute right-0 top-0 h-full w-1/3 border-l border-[#ff5a16]/15 bg-[#ff5a16]/[.025]" />
              <p className="eyebrow">The next move / 07</p>
              <h2 id="contact-heading" className="display-lg relative mt-6 max-w-[820px]">Bring us the thing<br /><span className="text-[#ff5a16]">worth building.</span></h2>
              <div className="relative mt-10 flex flex-col items-start gap-8 sm:flex-row sm:items-center sm:justify-between">
                <p className="max-w-[420px] text-sm leading-6 text-[#938b80]">A new platform. A system under pressure. A business that needs to move with more certainty. Start with the honest version.</p>
                <button onClick={openContact} className="solid-button flex shrink-0 items-center gap-4 bg-[#ff5a16] px-6 py-4 font-mono-custom text-[10px] uppercase tracking-[.13em] text-[#17120e]" data-testid="button-open-contact">Talk to an engineer <ArrowUpRight size={16} /></button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[#332e29] bg-[#10100f] px-5 py-10 lg:px-10">
        <div className="mx-auto flex max-w-[1240px] flex-col justify-between gap-8 md:flex-row md:items-end">
          <div><a href="#top" className="font-display text-2xl font-bold uppercase tracking-[.08em]" data-testid="link-footer-logo">Chingon<span className="text-[#ff5a16]">.</span></a><p className="mt-4 max-w-[260px] text-xs leading-5 text-[#756d63]">Digital infrastructure for organizations building what matters.</p></div>
          <div className="flex flex-col gap-3 md:items-end"><a href="mailto:hello@chingon.industries" className="font-mono-custom text-[11px] uppercase tracking-[.1em] text-[#ff7a45] hover:text-[#f1eadf]" data-testid="link-footer-email">hello@chingon.industries</a><p className="font-mono-custom text-[9px] uppercase tracking-[.1em] text-[#5f584f]">© 2024 Chingon Industries</p></div>
        </div>
      </footer>

      {contactOpen && <ContactModal onClose={() => setContactOpen(false)} />}
    </div>
  );
}

function Router() {
  return (
    <ErrorBoundary resetKey={window.location.pathname}>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;